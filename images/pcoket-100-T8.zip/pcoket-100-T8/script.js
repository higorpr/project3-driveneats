function perguntarIdade(){

    const ano = Number( prompt("Ano de nascimento") );
    
    const anoAtual = 2022;
    const idade = anoAtual - ano;

    if ( idade > 17 ) {        
        const painel = document.querySelector('.selecionar-jogo');
        painel.classList.remove('escondido');        
    }else{
        const paragrafo = document.querySelector('.aviso');    
        paragrafo.innerHTML = `Opa! Foi mal! voce tem ${idade} anos e por isso nao tem idade para jogar`;
    }
    
}

function selecionarJogo(classeBotao){

    const botaoSelecionado = document.querySelector('.jogo .selecionado');

    if ( botaoSelecionado !== null){
        botaoSelecionado.classList.remove('selecionado');
    }

    const seletor = '.'+classeBotao;    
    const botao = document.querySelector(seletor);
    botao.classList.add('selecionado');

}

function selecionarQtdeJogadores(classeBotao){

    const botaoSelecionado = document.querySelector('.qtd-jogadores .selecionado');

    if ( botaoSelecionado !== null){
        botaoSelecionado.classList.remove('selecionado');
    }

    const seletor = '.'+classeBotao;    
    const botao = document.querySelector(seletor);
    botao.classList.add('selecionado');

}